<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\support\Facades\DB;

class login extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('login')->insert([
            'name'=>'vishal',
            'email'=>'vishal@gmail.com',
            'mobile'=>'6354048082',
            'password'=>'123'
        ]);
    }
}
