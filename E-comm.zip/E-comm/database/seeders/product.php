<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Illuminate\support\Facades\DB;

class product extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('product')->insert([
            [
                'name'=>' Drone Camera',
                'price'=>'20000',
                'category'=>'Drone',
                'description'=>'Organly foldeble Drone with camera',
                'gallery'=>'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTuRRLvvEro7atlfvfdFWDJfBFkCrL1glbv3dJ1M0vGdG54760Z3KgtNm8ZcOni8a0qOYrxBrsFTcMzCCzE_aZWJSJ1nXAnWzRtzPK3zQghRLbqwgACisGE&usqp=CAE'
                
            ],
      
        ]);
    }
}
