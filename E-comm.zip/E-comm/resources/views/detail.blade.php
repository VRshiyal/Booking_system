
@extends('master')

    @section("content")
    <html lang="en">
    <head>
        <title>Product</title>
        <link rel="stylesheet" href="{{asset('css/app.css')}}">                    
    </head>
    <body>
        
    </body>
    </html>
    
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                        <img src="{{$product['gallery']}}" alt="">
                </div>
                <div class="col-sm-6">

                </div>
            </div>
             
         
        </div>
   
    @endsection

   