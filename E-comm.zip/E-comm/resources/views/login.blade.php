
@extends('master')

    @section("content")
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>LOGIN_PAGE</title>
        <link rel="stylesheet" href="{{asset('css/app.css')}}">
    </head>
    <body>
        
    </body>
    </html>
       <div class="container custom-login bg-danger mt-4 ">
            <div class="row">
                <div class="col-sm-4 col-sm-offset-4">

                 <form action="login" method="POST">
                    @csrf
                    <div class="form-group">
                            <label for="exampleInputEmail1"><img width="40" height="40" src="https://img.icons8.com/ultraviolet/40/person-male.png" alt="person-male"/>Username</label>
                            <input type="text" name="name" class="form-control"  id="exampleInputEmail1" aria-describedby="emailHelp" placeholder=" Enter your Username">
                            <span class="text-danger">
                                @error('name')
                                    {{$message}}
                                @enderror
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                            <span class="text-danger">
                                @error('email')
                                    {{$message}}
                                @enderror
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Mobile_No</label>
                            <input type="number" name="mobile"bile class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Mobile_No">
                            <span class="text-danger">
                                @error('mobile')
                                    {{$message}}
                                @enderror
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder=" Enter Your Password">
                            <span class="text-danger">
                                @error('password')
                                    {{$message}}
                                @enderror
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Conform_Password</label>
                            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder=" Enter Your Password">
                            <span class="text-danger">
                                @error('password')
                                    {{$message}}
                                @enderror
                            </span>
                        </div>
                        <div class="">
                        <button type="submit" class="btn btn-primary form-control">Submit</button>
                        </div>

                     </form>
                     
       
                </div>
            </div>
        </div>
   
    @endsection
