<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\user;
use app\models\product;


class productcontroller extends Controller
{
    function index()
    {
        $data= product::all();
         return view('product',['products'=>$data]);
   }

 function detail($id)
{
    return product::find($id);
    return view('detail',['product'=>$data]);
}
}
