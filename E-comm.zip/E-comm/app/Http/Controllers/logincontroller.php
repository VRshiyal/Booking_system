<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class logincontroller extends Controller
{
   
      
    public function login(Request $req)
    {
        $req->validate([
            'name'=>'required',
            'email'=>'required|email',
           // 'phone' => 'required|numeric|min:8|max:11',
            'password'=>'required|',
        ]);
        $data= new login();
            
        $data->name=$req->name;
        $data->email=$req->email;
     //   $data->mobile=$req->mobile;
        $data->password=Hash::make($req->password);
        
        
        $data->save();

        return redirect('home');
    }
    public function logindata(Request $req)
    {
        return "login page";
    }
}


