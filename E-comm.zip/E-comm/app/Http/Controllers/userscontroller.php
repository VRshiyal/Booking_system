<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\DB;
use App\models\user;
use users;
use App\models\usersmodel;
use Illuminate\support\Facades\Hash;

class userscontroller extends Controller
{
    
    
    public function logindata(Request $req)
    {

       $user= user::where(['email'=>$req->email])->first();
      // return $user->password;
        if(!$user || !Hash::check($req->password,$user->password))
            {
                return "usename or password dos not macth";
               // return redirect('login');
            }
            else
            {
                $req->session()->put('user',$user);
                return redirect('product');
            }
    }
      
      
    public function sigdata(Request $req)
    {
        $req->validate([
            'name'=>'required',
            'email'=>'required|email',
           // 'phone' => 'required|numeric|min:8|max:11',
            'password'=>'required|',
        ]);
        $data= new login();
            
        $data->name=$req->name;
        $data->email=$req->email;
       // $data->mobile=$req->mobile;
        $data->password=Hash::make($req->password);
        
        
        $data->save();

        return redirect('home');
    }
}
