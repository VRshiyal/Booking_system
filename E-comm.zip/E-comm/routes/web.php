<?php

use Illuminate\Support\Facades\Route;

use app\Http\controllers\userscontroller;
use app\Http\controllers\productcontroller;
use app\Http\controllers\logincontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('index');
});

route::POST('/sigdata',[logincontroller::class,'login']);
route::POST('/logindata',[App\Http\Controllers\logincontroller::class,'logindata']);

route::get('/product',[App\Http\Controllers\productcontroller::class,'index']);
route::get("detail/{id}",[App\Http\Controllers\productcontroller::class,'detail']);

//route::POST('/data','App\Http\Controllers\userscontroller@data');